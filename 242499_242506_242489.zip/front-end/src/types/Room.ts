export interface Room {
    id: number;
    roomNumber: number;
    roomCapacity: number;
    basePrice: number;
}