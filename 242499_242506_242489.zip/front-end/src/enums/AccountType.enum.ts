export enum AccountTypeEnum {
    ADMIN = 'ADMIN',
    CLIENT = 'CLIENT',
    RESOURCE_MANAGER = 'RESOURCE_MANAGER',
}