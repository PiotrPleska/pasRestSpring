package com.example.passpringrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class PasSpringRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(PasSpringRestApplication.class, args);
    }

}
