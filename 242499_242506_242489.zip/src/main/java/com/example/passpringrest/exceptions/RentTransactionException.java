package com.example.passpringrest.exceptions;

public class RentTransactionException extends RuntimeException {

        public RentTransactionException(String message) {
            super(message);
        }

}
